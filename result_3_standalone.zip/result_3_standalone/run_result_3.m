function run_result_3()
% RUN_RESULT_3  One-click, stand-alone, four-policy comparison.
% Place all five .m files in ONE folder and run this function in MATLAB.
% No existing .mat, .csv or results files are read. Each run starts afresh.
%
% Cost sensitivity cases reuse only fresh, in-memory policy-state quantities
% computed in the SAME run: changing costs cannot change transition kernels.
% Physical changes (lambda, alpha, alphaS) always recompute everything.
%
% All cost-only candidate evaluations skip MTTF/reliability recursion, as V6.
% Any failed candidate is retained and reported, not silently treated as valid.

clc;
here=fileparts(mfilename('fullpath'));
addpath(here);
outdir=fullfile(here,'result_3');
if ~exist(outdir,'dir'), mkdir(outdir); end
logfile=fullfile(outdir,'result_3_log.txt');
if exist(logfile,'file'), delete(logfile); end
diary(logfile); diary on;
cleanupDiary=onCleanup(@() diary('off')); %#ok<NASGU>
allTimer=tic;

%% Configuration: safe to adjust WITHOUT changing model equations
cfg.useParallel = true;
cfg.displayEverySeconds = 5;
cfg.fullGridVerification = false; % true: full 0.01 mesh for RI,M (slower)
cfg.abortIfTooManyFailures = true;

% Global-search mesh followed by 0.01 local refinement at EACH cost scenario.
% Lower bound 0.05 avoids numerical singularities at extremely small M.
% Search boundary warnings are issued when a solution is near either edge.
cfg.RIcoarse = 0.05:0.05:0.95;
cfg.Mcoarse  = 0.05:0.05:0.95; % M/L ratios
cfg.Mpolicy2 = 0.01:0.01:0.99;
cfg.Tcoarse  = unique([0.25,0.5,1:1:16,20,24]);
cfg.RIlocalStep=0.01;
cfg.MlocalStep=0.01;
cfg.TlocalStep=0.10;
cfg.RIlocalRadius=0.07;
cfg.MlocalRadius=0.07;
cfg.TlocalRadius=0.6;

%% Uniform baseline physical and cost parameters (from V6)
p0=struct('alpha',1.02,'beta',1.20,'lambda',0.25, ...
   'alphaS',2.5,'betaS',1.0,'p',6,'q',5,'L',12.5, ...
   'Ci',10,'Cm',100,'Cp',280,'Cc',350,'Cd',50);
% Baseline is calculated internally from scratch solely to share the new
% physical-state candidate pool with two cost-only experiments.
% It is deliberately NOT included in the published three-row output.
% Gamma shock magnitude: alphaS=1.5 (betaS=1 RATE, mean=1.5).
labels={'Baseline (internal reference)'; ...
        'Low shock magnitude (alphaS=1.5)'; ...
        'Low preventive maintenance cost (Cm=75)'; ...
        'Low inspection cost (Ci=5)'};
pars=repmat(p0,4,1);
pars(2).alphaS=1.5;
pars(3).Cm=75;
pars(4).Ci=5;
physicalRows=[1 2];
numConditions=numel(labels);
numPhysical=numel(physicalRows);
numStrategies=4;
strategies={'Hybrid','Policy 1','Policy 2','Periodic'};

fprintf('\n============================================================\n');
fprintf(' RESULT_3 -- three supplementary conditions, computed from scratch\n');
fprintf(' %d experimental conditions; %d strategies\n',numConditions,numStrategies);
fprintf(' Gamma parameters use RATE parameterization (beta, betaS).\n');
fprintf('============================================================\n');
fprintf('Results directory: %s\n',outdir);

%% Set up parallel workers once for the entire experiment
pool = [];
if cfg.useParallel && license('test','Distrib_Computing_Toolbox')
    try
        pool=gcp('nocreate');
        if isempty(pool)
            fprintf('[parallel] Starting process pool with MATLAB default worker count...\n');
            pool=parpool('local');
        end
        fprintf('[parallel] ACTIVE: %d workers\n',pool.NumWorkers);
    catch ME
        fprintf(2,'[parallel] Process pool failed: %s\n',ME.message);
        try
            fprintf('[parallel] Trying thread-based pool...\n');
            pool=parpool('Threads');
            fprintf('[parallel] ACTIVE: %d thread workers\n',pool.NumWorkers);
        catch ME2
            fprintf(2,'[parallel] Thread pool also failed: %s\n',ME2.message);
            fprintf('[parallel] Falling back to serial mode; results remain valid.\n');
            pool=[];
        end
    end
else
    fprintf('[parallel] Toolbox not found or disabled: serial mode.\n');
end

%% Preallocate results and run physical scenarios
% For the baseline (row 1), optimize all four cost variants from one fresh
% physical candidate pool. Other physical scenarios use their own models.
costResults=nan(numConditions,numStrategies);
chosen=nan(numConditions,numStrategies,2);
metrics=nan(numConditions,numStrategies,5); % event/time rates: inspection, PM, PR, CR, downtime
maxCorrectedMassError=nan(numConditions,numStrategies);
numCandidates=zeros(numConditions,numStrategies);
scenarioTimings=zeros(numPhysical,numStrategies);
fullDetails=cell(numPhysical,numStrategies);

for ip=physicalRows
    phys=pars(ip);
    costRows=ip;
    if ip==1, costRows=[1,3,4]; end
    costMatrix=zeros(numel(costRows),5);
    for j=1:numel(costRows)
        costMatrix(j,:)=get_cost_vector(pars(costRows(j)));
    end
    fprintf('\n\n############################################################\n');
    fprintf('PHYSICAL SCENARIO %d/%d: %s (lambda=%.3f, alpha=%.3f, alphaS=%.3f)\n', ...
        ip,numPhysical,labels{ip},phys.lambda,phys.alpha,phys.alphaS);
    fprintf('############################################################\n');
    for im=1:numel(strategies)
        strategy=strategies{im};
        timer=tic;
        fprintf('\n[%d/%d, %d/%d] %s -- precalculation and optimization\n', ...
            ip,numPhysical,im,numStrategies,strategy);
        try
            [answ,detail] = optimize_strategy(strategy,phys,costMatrix,cfg,pool);
        catch ME
            fprintf(2,'FATAL [%s, %s]: %s\n',labels{ip},strategy,ME.message);
            rethrow(ME);
        end
        scenarioTimings(ip,im)=toc(timer);
        fullDetails{ip,im}=detail;
        for j=1:numel(costRows)
            rr=costRows(j);
            costResults(rr,im)=answ(j).cost;
            chosen(rr,im,:)=reshape(answ(j).decision,[1,1,2]);
            metrics(rr,im,:)=reshape(answ(j).rates,[1,1,5]);
            maxCorrectedMassError(rr,im)=answ(j).massError;
            numCandidates(rr,im)=detail.numCandidates;
            fprintf('  %-33s cost=%11.6f  d1=%9.5g d2=%9.5g  [%s]\n', ...
                labels{rr},answ(j).cost,answ(j).decision(1), ...
                answ(j).decision(2),strategy);
        end
        fprintf('  %s elapsed: %.1f sec\n',strategy,scenarioTimings(ip,im));
        % Save incremental checkpoint for crash recovery, never read as input.
        save(fullfile(outdir,'result_3_checkpoint.mat'), ...
            'costResults','chosen','metrics','maxCorrectedMassError', ...
            'scenarioTimings','pars','labels','strategies','-v7.3');
    end
end

%% Compile paper-ready summary
bestBaseline=min(costResults(:,2:4),[],2);
improvement=(bestBaseline-costResults(:,1))./bestBaseline*100;
Summary=table(string(labels),[pars.lambda]',[pars.alpha]',[pars.alphaS]',[pars.Ci]', ...
    [pars.Cm]',[pars.Cc]',costResults(:,1),costResults(:,2), ...
    costResults(:,3),costResults(:,4),improvement, ...
    'VariableNames',{'Condition','lambda','alpha','alphaS','Ci','Cm','Cc', ...
    'Proposed','Policy1','Policy2','Periodic','ImprovementPct'});

nrow=numConditions*numStrategies;
cond= strings(nrow,1); policy=strings(nrow,1);
var1=nan(nrow,1);var2=nan(nrow,1);cstar=nan(nrow,1);
insp=nan(nrow,1);pm=nan(nrow,1);pr=nan(nrow,1);
cr=nan(nrow,1);down=nan(nrow,1);mass=nan(nrow,1);
candidates=nan(nrow,1);
for rr=1:numConditions
 for mm=1:numStrategies
    ix=(rr-1)*numStrategies+mm;
    cond(ix)=string(labels{rr});policy(ix)=string(strategies{mm});
    var1(ix)=chosen(rr,mm,1);var2(ix)=chosen(rr,mm,2);
    cstar(ix)=costResults(rr,mm);
    insp(ix)=metrics(rr,mm,1);pm(ix)=metrics(rr,mm,2);
    pr(ix)=metrics(rr,mm,3);cr(ix)=metrics(rr,mm,4);
    down(ix)=metrics(rr,mm,5);
    mass(ix)=maxCorrectedMassError(rr,mm);
    candidates(ix)=numCandidates(rr,mm);
 end
end
Details=table(cond,policy,var1,var2,cstar,insp,pm,pr,cr,down,mass,candidates, ...
    'VariableNames',{'Condition','Policy','Decision1_RI_or_T','Decision2_M', ...
    'OptimalCost','InspectionRate','PMRate','PreventiveReplacementRate', ...
    'CorrectiveReplacementRate','DowntimeFraction','MaxCorrectedMassError', ...
    'CandidatesEvaluated'});

%% Export ONLY the three newly requested experiments.
% All four policy costs are fully optimized at each setting. The baseline
% candidate pool is computed by this run and is not an external input.
Summary=Summary(2:4,:);
Details=Details(5:16,:);
writetable(Summary,fullfile(outdir,'result_3.csv'));
writetable(Details,fullfile(outdir,'result_3_details.csv'));
save(fullfile(outdir,'result_3.mat'),'Summary','Details', ...
    'fullDetails','pars','cfg','chosen','metrics','costResults','scenarioTimings', ...
    'maxCorrectedMassError','-v7.3');
fprintf('\n============================================================\n');
disp(Summary);
fprintf('\nFINISHED in %.1f seconds\n',toc(allTimer));
fprintf('Summary CSV:  %s\n',fullfile(outdir,'result_3.csv'));
fprintf('Details CSV:  %s\n',fullfile(outdir,'result_3_details.csv'));
fprintf('MAT data:     %s\n',fullfile(outdir,'result_3.mat'));
fprintf('Log:          %s\n',logfile);
fprintf('IMPORTANT: Verify numerical diagnostics and boundary warnings before publication.\n');
end

function [answers,detail]=optimize_strategy(strategy,par,costMatrix,cfg,pool)
opts=make_options(strategy);
if strcmp(strategy,'Periodic')
    opts.tCompoundMax=max(cfg.Tcoarse);
end
% Precompute only for the present scenario. No external data files.
t=tic;
switch strategy
    case 'Hybrid',   prep=hybrid_model('prepare',par,opts);
    case 'Policy 1', prep=policy1_model('prepare',par,opts);
    case 'Policy 2', prep=policy2_model('prepare',par,opts);
    case 'Periodic', prep=periodic_model('prepare',par,opts);
end
fprintf('  Precomputation: %.2f sec\n',toc(t));

% Stage 1: broad search; Stage 2: 0.01 local refinements around EACH cost optimum.
coarse=make_coarse_grid(strategy,par,cfg);
[rawCoarse,errCoarse]=evaluate_candidate_batch(coarse,strategy,par,opts,prep,pool,cfg,'coarse');
valid=all(isfinite(rawCoarse(:,1:6)),2);
if cfg.abortIfTooManyFailures && nnz(valid)<max(3,round(.75*size(coarse,1)))
    error('%s coarse search: only %d/%d valid candidates. First error: %s', ...
        strategy,nnz(valid),size(coarse,1),first_error(errCoarse));
end
if ~any(valid), error('%s coarse search failed completely',strategy); end
coarseCosts=rawCoarse(:,1:5)*costMatrix';
coarseCosts(~valid,:)=inf;
centers=zeros(size(costMatrix,1),2);
for ic=1:size(costMatrix,1)
    [~,id]=min(coarseCosts(:,ic)); centers(ic,:)=coarse(id,:);
end

fine=zeros(0,2);
if cfg.fullGridVerification && ~strcmp(strategy,'Periodic')
    if strcmp(strategy,'Policy 2')
        fine=zeros(0,2); % Already 99-point complete grid.
    else
        [r,m]=ndgrid(.01:.01:.99, (.01:.01:.99)*par.L);
        fine=[r(:),m(:)];
    end
else
    for ic=1:size(centers,1)
        fine=[fine; local_grid(strategy,centers(ic,:),par,cfg)]; %#ok<AGROW>
    end
end
fine=unique(round(fine*1e8)/1e8,'rows');
% Compute NEW fine candidates only; existing candidates reused from this run.
[~,jPos]=ismember(fine,coarse,'rows');
fine=fine(jPos==0,:);
if isempty(fine)
    allD=coarse;allRaw=rawCoarse;allErr=errCoarse;
else
    [rawFine,errFine]=evaluate_candidate_batch(fine,strategy,par,opts,prep,pool,cfg,'refine');
    allD=[coarse;fine];allRaw=[rawCoarse;rawFine];allErr=[errCoarse;errFine];
end
valid=all(isfinite(allRaw(:,1:6)),2);
if ~any(valid), error('%s: no valid candidate after refinement',strategy); end
cost=allRaw(:,1:5)*costMatrix';
cost(~valid,:)=inf;
answerTemplate=struct('cost',nan,'decision',[nan,nan], ...
    'rates',nan(1,5),'massError',nan);
answers=repmat(answerTemplate,size(costMatrix,1),1);
for ic=1:size(costMatrix,1)
    [costmin,k]=min(cost(:,ic));
    answers(ic).cost=costmin;
    answers(ic).decision=allD(k,:);
    answers(ic).rates=allRaw(k,1:5);
    answers(ic).massError=allRaw(k,6);
    warn_boundary(strategy,allD(k,:),cfg,par);
    if allRaw(k,6)>2e-3
       warning('%s chosen policy mass error %.4g exceeds 2e-3; consider finer Nz/Nv.', ...
           strategy,allRaw(k,6));
    end
end
nFailed=nnz(~valid);
if nFailed>0, fprintf(2,'  %s WARNING: %d/%d candidates failed. First: %s\n', ...
    strategy,nFailed,size(allD,1),first_error(allErr));end
fprintf('  Evaluated %d unique candidates; %d failed.\n',size(allD,1),nFailed);
detail=struct('decisionGrid',allD,'candidateMetrics',allRaw, ...
    'candidateErrors',allErr,'costMatrix',costMatrix, ...
    'numCandidates',size(allD,1),'validCount',nnz(valid), ...
    'precomputationTimeSeconds',toc(t));
end

function opts=make_options(strategy)
% Retain corresponding source-engine quadrature choices.
opts=struct();opts.Nz=60;opts.Nv=80;
opts.useParallel=false;opts.showProgress=false;
switch strategy
    case 'Hybrid'
        opts.Ny=18;opts.NtInt=80;opts.Nconv=60;opts.NuRel=18;
        opts.NtRel=60;opts.tRelMaxFactor=2.5;
        opts.computeReliabilityCurve=false;
        opts.minMassWarning=5e-2;opts.warnOnMass=false;
    case 'Policy 1'
        opts.NtInt=100;opts.NtRel=301;opts.maxNtRel=4000;
        opts.dtRelMaximum=.20;opts.tRelMaxFactor=6;
        opts.reliabilityTailWarning=1e-5;
        opts.NtCompound=1201;opts.NuCompound=1201;
        opts.NfftCompound=8192;opts.tCompoundMax=60;
        opts.minMassWarning=1e-3;
    case 'Policy 2'
        opts.Nlag=48;opts.NtRel=501;opts.maxNtRel=2200;
        opts.dtRelMaximum=.25;opts.tRelMaxFactor=6;
        opts.kernelTailProbability=1e-8;
        opts.reliabilityTailWarning=1e-5;
        opts.NuInspection=1201;opts.NfftInspection=8192;
        opts.inspectionUpperFactor=12;opts.minMassWarning=1e-3;
    case 'Periodic'
        opts.NtInt=80;opts.NtRel=301;opts.maxNtRel=4000;
        opts.dtRelMaximum=.20;opts.tRelMaxFactor=6;
        opts.reliabilityTailWarning=1e-5;
        opts.NtCompound=1201;opts.NuCompound=1201;
        opts.NfftCompound=8192;opts.minMassWarning=1e-3;
end
end

function D=make_coarse_grid(strategy,par,cfg)
switch strategy
 case {'Hybrid','Policy 1'}
    [a,b]=ndgrid(cfg.RIcoarse,cfg.Mcoarse*par.L);
    D=[a(:),b(:)];
 case 'Policy 2'
    D=[nan(numel(cfg.Mpolicy2),1),cfg.Mpolicy2(:)*par.L];
 case 'Periodic'
    [a,b]=ndgrid(cfg.Tcoarse,cfg.Mcoarse*par.L);
    D=[a(:),b(:)];
end
end

function D=local_grid(strategy,center,par,cfg)
switch strategy
 case {'Hybrid','Policy 1'}
    r=local_axis(center(1),cfg.RIlocalRadius,cfg.RIlocalStep,.01,.99);
    m=local_axis(center(2)/par.L,cfg.MlocalRadius,cfg.MlocalStep,.01,.99)*par.L;
    [a,b]=ndgrid(r,m);D=[a(:),b(:)];
 case 'Policy 2'
    D=zeros(0,2); % full 99-point optimization already evaluated
 case 'Periodic'
    t=local_axis(center(1),cfg.TlocalRadius,cfg.TlocalStep,.1,max(cfg.Tcoarse));
    m=local_axis(center(2)/par.L,cfg.MlocalRadius,cfg.MlocalStep,.01,.99)*par.L;
    [a,b]=ndgrid(t,m);D=[a(:),b(:)];
end
end

function v=local_axis(mid,radius,step,lo,hi)
% Round grid nodes for robust union; include local edges for coverage.
v=unique([mid, (ceil(max(lo,mid-radius)/step)*step):step: ...
                    (floor(min(hi,mid+radius)/step)*step)]);
v=unique(round(v*1e8)/1e8);
v=v(v>=lo-1e-8 & v<=hi+1e-8);
end

function [values,errors]=evaluate_candidate_batch(D,strategy,par,opts,pre,pool,cfg,stage)
n=size(D,1);
values=nan(n,6); % [1,Epm,Epr,Ecr,Edowntime] / Ecycle; transition mass error
errors=strings(n,1);
if n==0,return;end
fprintf('  %-6s %s: %d candidates ...\n',stage,strategy,n);
t=tic;
completed=0;lastPrint=0;
if ~isempty(pool)
    dq=parallel.pool.DataQueue;
    afterEach(dq,@progress);
    parfor k=1:n
        try
            rep=eval_one(strategy,D(k,:),par,opts,pre);
            values(k,:)=extract_rates(rep);
        catch ME
            errors(k)=string(ME.message);
        end
        send(dq,1);
    end
else
    for k=1:n
        try
            rep=eval_one(strategy,D(k,:),par,opts,pre);
            values(k,:)=extract_rates(rep);
        catch ME
            errors(k)=string(ME.message);
        end
        progress(1);
    end
end
fprintf('  %-6s %s: DONE %d/%d, %.1f sec, errors %d\n', ...
    stage,strategy,nnz(isfinite(values(:,1))),n,toc(t),nnz(errors~=""));
    function progress(~)
        completed=completed+1;
        elapsed=toc(t);
        if elapsed-lastPrint >= cfg.displayEverySeconds || completed==n
            lastPrint=elapsed;
            v=max(completed/max(elapsed,eps),eps);
            fprintf('    [%s/%s] %d/%d (%.1f%%), elapsed %.0fs, ETA %.0fs\n', ...
                strategy,stage,completed,n,100*completed/n,elapsed,(n-completed)/v);
        end
    end
end

function rep=eval_one(strategy,d,par,opts,pre)
switch strategy
 case 'Hybrid',  rep=hybrid_model('evaluate',d,par,opts,pre);
 case 'Policy 1',rep=policy1_model('evaluate',d,par,opts,pre);
 case 'Policy 2',rep=policy2_model('evaluate',d,par,opts,pre);
 case 'Periodic',rep=periodic_model('evaluate',d,par,opts,pre);
end
end

function r=extract_rates(rep)
t=rep.expectedCycleLength;
if ~(isfinite(t)&&t>0),error('Invalid cycle length');end
c=rep.expectedCountsPerCycle;
r=[1,c.PM,c.preventiveReplacement,c.correctiveReplacement, ...
      rep.expectedDowntimePerCycle]/t;
if ~isfield(rep,'diagnostics')
    error('Missing numerical diagnostic');
end
r(6)=rep.diagnostics.maxCorrectedTransitionMassError;
if any(~isfinite(r)) || any(r(1:5)<-1e-10)
    error('Nonfinite or negative event/time rates');
end
if r(6)>0.1
    error('Numerical transition kernel error above 0.1');
end
% Check the original cost-rate equation agrees with extracted event rates.
cost=get_cost_vector(rep.parameters);
reconstructed=r(1:5)*cost';
if abs(reconstructed-rep.costRate)>2e-7*max(1,abs(rep.costRate))
    error('Cost-rate mismatch; %.6g vs %.6g',reconstructed,rep.costRate);
end
end

function cost=get_cost_vector(p)
cost=[p.Ci,p.Cm,p.Cp,p.Cc,p.Cd];
end

function warn_boundary(strategy,d,cfg,p)
switch strategy
 case {'Hybrid','Policy 1'}
    if d(1)<=.011 || d(1)>=.989 || d(2)/p.L<=.011 || d(2)/p.L>=.989
       warning('%s optimum at near-domain boundary: RI %.4g, M/L %.4g', ...
          strategy,d(1),d(2)/p.L);end
 case 'Policy 2'
    if d(2)/p.L<=.011 || d(2)/p.L>=.989
       warning('%s optimum at M/L boundary %.4g',strategy,d(2)/p.L);end
 case 'Periodic'
    if d(1)<=min(cfg.Tcoarse)+1e-8 || d(1)>=max(cfg.Tcoarse)-1e-8 ...
       || d(2)/p.L<=.011 || d(2)/p.L>=.989
       warning('%s optimum at search boundary T=%.4g, M/L=%.4g', ...
          strategy,d(1),d(2)/p.L);end
end
end

function msg=first_error(err)
ix=find(err~="",1);
if isempty(ix),msg='none';else,msg=char(err(ix));end
end
