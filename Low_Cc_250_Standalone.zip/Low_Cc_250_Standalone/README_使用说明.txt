低纠正更换成本 Cc=250，四种策略独立对比实验

1. 将文件夹解压至任意新路径。
2. 在 MATLAB 中打开 run_low_Cc_comparison.m，点击 Run。
3. 自动使用 MATLAB 当前已有并行池，或由 parpool('local') 根据本机默认配置确定 worker 数量。进程池无法启动时尝试线程池，最后退回串行。
4. 不读取以前保存的任何 .mat 或 .csv 文件；从头计算四种策略，并在 RESULTS/ 输出 Table_Comparison.csv、Detailed_Optimized_Policies.csv、all_results_this_run.mat、execution_log.txt。
5. 仅变更 Cc=250，其余基准参数保持 alpha=1.02, beta=1.20, lambda=0.25, alphaS=2.5, betaS=1, p=6, q=5, L=12.5, Ci=10, Cm=100, Cp=280, Cd=50。
6. 使用 Hybrid (Proposed policy)、Policy 1、Policy 2 和 Periodic (Policy 3)。
7. ImprovementPct 是相对三种基准策略中最低成本率的改善百分比；负值表示并非最优。
8. 使用粗网格 + 局部细化；如需在全局 0.01 网格验证最优点，请将 cfg.fullGridVerification=true（运行时间显著增加）。
9. 程序沿用原计算模块，包括数值转移概率校正；警告和数值误差需要检查。当前未在 MATLAB 环境运行验证。
