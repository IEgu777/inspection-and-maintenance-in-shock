四策略跨运行工况成本对比实验（独立运行版）
====================================

1. 使用方法
   解压整个压缩包到一个新文件夹，保留以下五个 .m 文件在同一目录：
       run_all_comparisons.m
       hybrid_model.m
       policy1_model.m
       policy2_model.m
       periodic_model.m
   在 MATLAB 中打开 run_all_comparisons.m，单击 Run。
   或在 MATLAB 命令行切换至该文件夹，然后输入：
       run_all_comparisons
   不要只复制主文件；模型函数文件必须与主文件放在一起。

2. 依赖
   MATLAB，Parallel Computing Toolbox（可并行）。
   优先启动本地进程池；如启动失败尝试线程池，再失败将自动串行计算。
   不设置人为 worker 上限，使用 MATLAB 本地并行配置确定数量。
   注意：本环境没有 MATLAB，因此尚未执行数值运行验证。

3. 实验条件（9行）
   Baseline: alpha=1.02, beta=1.20, lambda=0.25, alphaS=2.5,
             betaS=1.0, p=6, q=5, L=12.5;
             Ci=10, Cm=100, Cp=280, Cc=350, Cd=50。
   Low shock: lambda=0.10
   High shock: lambda=0.35
   Low degradation: alpha=0.70
   High degradation: alpha=1.40
   High shock magnitude: alphaS=3.5 (betaS=1.0 保持不变；平均冲击损伤从2.5增加到3.5，增加40%)
   High inspection cost: Ci=20
   High corrective replacement cost: Cc=500
   High preventive maintenance cost: Cm=125
   一次只变一个参数；四种策略在每种条件下都重新选择最优决策。

4. 算法加速和公正性
   使用模型原有的离散核、FFT预计算或Gamma混合级数。
   网格搜索不求 MTTF / 可靠度曲线，计算成本率所需周期期望与事件率。
   四个策略由同一主脚本分派 parfor 计算候选参数，定期打印进度/ETA。
   先在整个适用区间做粗网格，再在每一种成本方案对应的候选最优点
   周边执行细网格搜索；Policy2直接优化全部99个M值。
   这是数值网格最优解，不是全局最优的数学证明；应留意边界警告。

   【重要】成本场景只对成本系数进行变化。同一物理条件下，状态转移、
   平稳分布、检修事件率不随Ci,Cm,Cc变化。为了提速，本次程序会
   把【本次运行中刚刚算出】的全部候选策略事件率放在内存中，按新
   成本系数重新计算成本并分别细化各成本场景。绝不读取旧数据。
   改变 lambda、alpha 和 alphaS 时会全部重新生成相应概率分布及计算核。

5. 输出（运行后新建 RESULTS 子文件夹）
   Table_Comparison.csv          : 9行论文汇总表；四策略最低成本及改善率
   Detailed_Optimized_Policies.csv : 36行；最优决策、事件/检查率、停机率、误差诊断
   all_results_this_run.mat      : 本次计算网格结果及全部原始候选策略指标
   checkpoint_current_run.mat    : 本次计算过程中的断点数据（仅输出，不作输入）
   execution_log.txt             : 并行计算阶段时间、计算进度与警告记录
   Original_Baseline_Manuscript_Table3.csv : 原稿Table 3中的四策略Baseline参考数据（含成本、A和MTTF）
   Baseline_New_vs_Original.csv  : 本次新算的Baseline成本与原稿Table 3成本逐项比较

6. Improvement (%) 计算
   [min(Cost_Policy1, Cost_Policy2, Cost_Periodic) - Cost_Proposed]
   / min(Cost_Policy1, Cost_Policy2, Cost_Periodic) * 100。
   如为负值，应如实报告：该条件下Proposed不是最经济的策略。

7. 并行数量和数值精度
   并行工作进程数由 MATLAB 当前本地并行配置自动确定，不设置人为上限；如果已启动并行池，则直接复用。
   进程池无法启动时尝试 MATLAB 默认大小的线程池，仍失败则转串行计算。
   cfg.fullGridVerification = true 时，Hybrid/Policy1以99x99网格评价，
   计算量会显著增大；Periodic仍为分阶段网格。
   各策略原有的状态离散数Nz=60,Nv=80；如需高精度可修改
   make_options 函数对应部分，并检查错误诊断是否收敛。

8. 关于模型来源与限制
   四个数值核分别源自用户提供的 V6 Hybrid、V3 Fast Policy1、
   V3 Fast Policy2、V2 Fast Periodic 程序，保留其策略假设。
   没有在当前环境下运行 MATLAB，无法保证无需针对特定版本做微调。
   正式发表前应使用 MATLAB 对结果做独立验证、网格加密和数值收敛检查。

9. 本次调整（2026-11-20）
   高冲击强度 lambda=0.35；高预防性维修成本 Cm=125；新增高冲击幅值 alphaS=3.5。
   汇总 CSV 增加 alphaS 列。全部9组工况仍由程序独立计算，不读取过去的结果文件。

10. 本次调整（2026-11-20）
    High inspection cost 改为 Ci=20。
    新增原稿Table 3的Baseline参考数据：Proposed成本37.623, Policy1成本38.688,
    Policy2成本40.337, Periodic成本39.615；保留其原始阈值、可用度和MTTF。
    原稿结果只作为核对参考，绝不参与优化。主程序仍从头计算全部9组工况。
    如果新计算的Baseline与原稿数据不一致，应检查数值精度、搜索范围与版本，
    不要用原稿结果替代程序算出的结果。
